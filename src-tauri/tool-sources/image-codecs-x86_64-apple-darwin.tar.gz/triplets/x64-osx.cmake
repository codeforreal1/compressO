include("/Users/niraj/Documents/compressO/src-tauri/.toolchain-cache/image-codecs/vcpkg-4f973280dd95e3902b3410933fb2ce108bb29d1d/triplets/community/x64-osx.cmake")
set(VCPKG_BUILD_TYPE release)
set(VCPKG_OSX_DEPLOYMENT_TARGET 11.0)
