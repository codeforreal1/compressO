include("/work/src-tauri/.toolchain-cache/image-codecs/vcpkg-4f973280dd95e3902b3410933fb2ce108bb29d1d/triplets/x64-linux.cmake")
set(VCPKG_BUILD_TYPE release)
set(VCPKG_CRT_LINKAGE static)
set(VCPKG_CMAKE_CONFIGURE_OPTIONS -DCMAKE_EXE_LINKER_FLAGS=-static\ -no-pie)
