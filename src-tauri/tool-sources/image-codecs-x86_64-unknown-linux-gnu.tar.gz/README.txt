CompressO image codecs. vcpkg revision: 4f973280dd95e3902b3410933fb2ce108bb29d1d
See docs/image-codecs.md for build and relink instructions.
The overlay selects the primary HEIF image and rejects sequences.
